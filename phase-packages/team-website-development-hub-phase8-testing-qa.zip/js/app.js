const $=id=>document.getElementById(id);
let tests=JSON.parse(localStorage.getItem("hub-tests")||"null")||[
{id:"t1",title:"Login works on desktop",area:"Authentication",status:"passed"},
{id:"t2",title:"Login works on mobile",area:"Responsive",status:"passed"},
{id:"t3",title:"All navigation links work",area:"UI/UX",status:"passed"},
{id:"t4",title:"Forms validate required fields",area:"Authentication",status:"todo"},
{id:"t5",title:"No console errors on key pages",area:"Performance",status:"todo"},
{id:"t6",title:"RLS policies protect project data",area:"Security",status:"blocked"},
{id:"t7",title:"Production environment variables configured",area:"Deployment",status:"todo"}
];
let bugs=JSON.parse(localStorage.getItem("hub-bugs")||"null")||[
{id:"b1",title:"Mobile menu overlaps footer",severity:"medium",status:"open"},
{id:"b2",title:"Client approval button needs loading state",severity:"low",status:"open"}
];
function save(){localStorage.setItem("hub-tests",JSON.stringify(tests));localStorage.setItem("hub-bugs",JSON.stringify(bugs))}
function toast(m){$("toast").textContent=m;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2500)}
function stats(){let total=tests.length,passed=tests.filter(x=>x.status==="passed").length,open=bugs.filter(x=>x.status!=="resolved").length,score=Math.round((passed/Math.max(total,1))*100);$("total").textContent=total;$("passed").textContent=passed;$("bugs").textContent=open;$("score").textContent=score+"%";$("scoreRing").textContent=score+"%";let ready=score===100&&open===0&&!tests.some(x=>x.status==="blocked");$("releaseState").textContent=ready?"Release ready":"Not ready";$("gateTitle").textContent=ready?"Release ready":"Release not ready";return ready}
function renderTests(){let f=$("filter").value;let arr=tests.filter(x=>f==="all"||x.status===f);$("tests").innerHTML=arr.map(t=>`<div class="test"><span class="check ${t.status}">${t.status==="passed"?"✓":t.status==="failed"?"!":t.status==="blocked"?"×":"○"}</span><div><b>${t.title}</b><small>${t.area}</small></div><select data-id="${t.id}"><option value="todo" ${t.status==="todo"?"selected":""}>To do</option><option value="passed" ${t.status==="passed"?"selected":""}>Passed</option><option value="failed" ${t.status==="failed"?"selected":""}>Failed</option><option value="blocked" ${t.status==="blocked"?"selected":""}>Blocked</option></select></div>`).join("");document.querySelectorAll(".test select").forEach(s=>s.onchange=()=>{let t=tests.find(x=>x.id===s.dataset.id);t.status=s.value;save();render();toast("Test status updated.")})}
function renderBugs(){$("bugList").innerHTML=bugs.map(b=>`<div class="bug"><span class="sev ${b.severity}"></span><div><b>${b.title}</b><small>${b.severity} · ${b.status}</small></div><button data-bug="${b.id}">${b.status==="open"?"Resolve":"Reopen"}</button></div>`).join("");document.querySelectorAll("[data-bug]").forEach(x=>x.onclick=()=>{let b=bugs.find(v=>v.id===x.dataset.bug);b.status=b.status==="open"?"resolved":"open";save();render();toast("Bug status updated.")})}
function renderGate(){let items=[["All tests passed",tests.every(t=>t.status==="passed")],["No open bugs",bugs.every(b=>b.status==="resolved")],["No blocked checks",!tests.some(t=>t.status==="blocked")],["Security checks passed",tests.some(t=>t.area==="Security"&&t.status==="passed")]];$("gateItems").innerHTML=items.map(x=>`<div class="gate ${x[1]?"yes":"no"}"><span>${x[1]?"✓":"!"}</span>${x[0]}</div>`).join("")}
function render(){stats();renderTests();renderBugs();renderGate()}
$("filter").onchange=renderTests;$("runAudit").onclick=()=>{let ready=stats();renderGate();toast(ready?"Release audit passed.":"Release blocked: fix remaining checks.")};
$("newTest").onclick=()=>$("testModal").classList.remove("hidden");$("closeTest").onclick=()=>$("testModal").classList.add("hidden");
$("testForm").onsubmit=e=>{e.preventDefault();tests.push({id:"t"+Date.now(),title:$("testTitle").value,area:$("testArea").value,status:"todo"});save();e.target.reset();$("testModal").classList.add("hidden");render();toast("Test case created.")};
$("newBug").onclick=()=>$("bugModal").classList.remove("hidden");$("closeBug").onclick=()=>$("bugModal").classList.add("hidden");
$("bugForm").onsubmit=e=>{e.preventDefault();bugs.unshift({id:"b"+Date.now(),title:$("bugTitle").value,severity:$("bugSeverity").value,status:"open"});save();e.target.reset();$("bugModal").classList.add("hidden");render();toast("Bug reported.")};
$("theme").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("qa-theme",document.body.classList.contains("light")?"light":"dark")};if(localStorage.getItem("qa-theme")==="light")document.body.classList.add("light");render();
