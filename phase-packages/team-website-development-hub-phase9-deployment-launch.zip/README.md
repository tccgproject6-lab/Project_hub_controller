# Phase 9 — Deployment & Launch Center

## Included
- Release creation
- Versioning and release notes
- Pre-deployment checklist
- Release approval gate
- Development / Staging / Production states
- Deployment lock until checks and approval are complete
- Post-launch maintenance dashboard
- Dark/light mode
- Responsive release UI
- Supabase release, checks, deployments, approvals and maintenance schema
- RLS policies

## Important
The frontend records a demo production state locally; it does NOT deploy a real website by itself.

For real deployment, connect the deployment service of choice (for example GitHub Actions plus Render/Vercel/Netlify, or another CI/CD provider) through a secure backend/webhook. Never put provider tokens in frontend JavaScript.

## Suggested production flow
1. Developer pushes code.
2. CI builds and tests.
3. Staging deployment is created.
4. QA release checks are verified.
5. Authorized admin approves.
6. Deployment service promotes the release to production.
7. Team Hub records deployment URL, status and logs.
8. Maintenance checks monitor uptime, SSL, backups, security and performance.
