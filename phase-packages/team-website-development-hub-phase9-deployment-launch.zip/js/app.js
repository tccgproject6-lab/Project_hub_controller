const $=id=>document.getElementById(id);
let release={version:"v1.0.0",approved:false,deployed:false};
let checks=JSON.parse(localStorage.getItem("hub-release-checks")||"null")||[
{id:"build",title:"Production build succeeds",detail:"No build errors or failed compilation.",required:true,passed:false},
{id:"tests",title:"All critical tests passed",detail:"No failed or blocked release tests.",required:true,passed:false},
{id:"bugs",title:"No critical or high open bugs",detail:"Resolve release-blocking defects.",required:true,passed:false},
{id:"security",title:"Security review completed",detail:"Authentication, RLS and secrets reviewed.",required:true,passed:false},
{id:"env",title:"Production environment configured",detail:"Required environment variables are present.",required:true,passed:false},
{id:"domain",title:"Domain and SSL verified",detail:"Production domain resolves over HTTPS.",required:true,passed:false},
{id:"backup",title:"Backup and rollback plan ready",detail:"Recovery procedure has been documented.",required:true,passed:false},
{id:"content",title:"Content and client approval verified",detail:"Final content is approved.",required:true,passed:false}
];
function save(){localStorage.setItem("hub-release-checks",JSON.stringify(checks));localStorage.setItem("hub-release",JSON.stringify(release))}
function toast(m){$("toast").textContent=m;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),2600)}
function render(){
$("version").textContent=release.version;
let passed=checks.filter(x=>x.passed).length;
$("passed").textContent=`${passed}/${checks.length}`;
let ready=checks.every(x=>x.passed)&&release.approved;
$("stateText").textContent=ready?"Ready to deploy":"Not ready";
$("stateHint").textContent=ready?"All release gates cleared":"Complete all mandatory gates";
$("stateDot").className=ready?"ready":"blocked";
$("approval").textContent=release.approved?"Approved":"Pending";
$("approvalBadge").textContent=release.approved?"Approved":"Pending";
$("approvalBadge").className="badge "+(release.approved?"approved":"pending");
$("env").textContent=release.deployed?"Production":"Staging";
$("prodStatus").textContent=release.deployed?"Live":"Locked";
$("prodStatus").className=release.deployed?"ok":"lock";
$("deploy").disabled=!ready||release.deployed;
$("deploy").textContent=release.deployed?"✓ Production deployed":"🚀 Deploy to production";
$("checks").innerHTML=checks.map(c=>`<div class="check ${c.passed?"passed":""}">
<span class="box">${c.passed?"✓":"○"}</span><div><b>${c.title}</b><small>${c.detail}</small></div>
<button data-check="${c.id}">${c.passed?"Passed":"Mark passed"}</button></div>`).join("");
document.querySelectorAll("[data-check]").forEach(b=>b.onclick=()=>{
let c=checks.find(x=>x.id===b.dataset.check);c.passed=!c.passed;save();render();toast(c.passed?"Check passed.":"Check reopened.");
});
}
$("audit").onclick=()=>{render();toast("Release checks refreshed. Each gate must be verified by the team.");};
$("approve").onclick=()=>{
let all=checks.every(x=>x.passed);
if(!all){toast("Approval blocked until all release checks pass.");return}
release.approved=!release.approved;save();render();toast(release.approved?"Release approved.":"Approval revoked.");
};
$("deploy").onclick=()=>{
if(checks.every(x=>x.passed)&&release.approved){
release.deployed=true;save();render();toast("Production state recorded. Connect your hosting provider for the actual deployment.");
}
};
$("newRelease").onclick=()=>$("modal").classList.remove("hidden");
$("close").onclick=()=>$("modal").classList.add("hidden");
$("releaseForm").onsubmit=e=>{
e.preventDefault();release={version:$("rVersion").value.trim(),approved:false,deployed:false};checks=checks.map(x=>({...x,passed:false}));save();$("modal").classList.add("hidden");e.target.reset();render();toast("New release created.");
};
$("theme").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("launch-theme",document.body.classList.contains("light")?"light":"dark")};
if(localStorage.getItem("launch-theme")==="light")document.body.classList.add("light");
let saved=JSON.parse(localStorage.getItem("hub-release")||"null");if(saved)release=saved;
render();
