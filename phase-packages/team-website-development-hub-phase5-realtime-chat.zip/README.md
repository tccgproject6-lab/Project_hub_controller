# Phase 5 — Realtime Team Chat

## Included
- WhatsApp-inspired responsive chat UI
- Direct and group conversation presentation
- Search conversations
- Message composer
- Read-style indicators in demo UI
- New group modal
- Dark/light mode
- Supabase schema for conversations, members, messages and reads
- RLS policies
- Realtime publication setup

## Supabase
Run `supabase/chat_schema.sql` after the Phase 2 schema and Phase 4 project schema.

Then connect the UI to your Supabase URL and anon key in `js/config.js`.

The current frontend intentionally has a demo fallback. The database schema is ready for the realtime connector; the production connector should be wired only after the authenticated user/session and conversation membership are available.

Never use the Supabase service-role key in frontend code.
