const $=id=>document.getElementById(id);
const STORAGE="teamhub-code-studio";
let files=JSON.parse(localStorage.getItem(STORAGE)||"null")||{
 "index.html":`<!doctype html>
<html>
<head><title>Hassaco Website</title></head>
<body>
  <h1>Hello Team Hub 👋</h1>
  <p>Edit this code and press Run.</p>
  <button onclick="sayHello()">Test JavaScript</button>
  <script src="script.js"><\/script>
</body>
</html>`,
 "style.css":`body{font-family:Inter,Arial,sans-serif;padding:40px;background:#f4f7fb;color:#172033}h1{font-size:36px}button{padding:10px 15px;border:0;border-radius:9px;background:#172033;color:white}`,
 "script.js":`function sayHello(){console.log("JavaScript is running successfully.");alert("Hello from Code Studio!");}`
};
let current="index.html";
function save(){localStorage.setItem(STORAGE,JSON.stringify(files));$("saved").textContent="Saved";setTimeout(()=>$("saved").textContent="Saved locally",900)}
function renderFiles(){
 $("fileList").innerHTML=Object.keys(files).map(f=>`<button class="file ${f===current?"active":""}" data-file="${f}"><span>${icon(f)}</span>${f}</button>`).join("");
 document.querySelectorAll(".file").forEach(b=>b.onclick=()=>openFile(b.dataset.file));
}
function icon(f){if(f.endsWith(".html"))return"🌐";if(f.endsWith(".css"))return"🎨";if(f.endsWith(".js"))return"⚡";return"📄"}
function renderTabs(){$("tabs").innerHTML=`<span>${icon(current)}</span><b>${current}</b>`}
function openFile(f){current=f;$("code").value=files[f];renderFiles();renderTabs();updateCursor()}
$("code").addEventListener("input",()=>{files[current]=$("code").value;$("saved").textContent="Unsaved";updateCursor()});
function updateCursor(){let p=$("code").selectionStart||0,pre=$("code").value.slice(0,p),lines=pre.split("\n");$("cursor").textContent=`Ln ${lines.length}, Col ${lines.at(-1).length+1}`}
$("code").addEventListener("keyup",updateCursor);$("code").addEventListener("click",updateCursor);
function log(type,text){let d=document.createElement("div");d.className=type;d.textContent=text;$("logs").appendChild(d);$("logs").scrollTop=$("logs").scrollHeight}
function buildHTML(){
 let html=files["index.html"]||"";
 const css=files["style.css"]||"";
 const js=files["script.js"]||"";
 html=html.replace(/<link[^>]+href=["']style\.css["'][^>]*>/gi,`<style>${css}</style>`);
 if(!/style\.css/i.test(html) && css)html=html.replace("</head>",`<style>${css}</style></head>`);
 html=html.replace(/<script[^>]+src=["']script\.js["'][^>]*><\/script>/gi,`<script>${js.replace(/<\/script/gi,"<\\/script")}<\/script>`);
 if(!/script\.js/i.test(html) && js)html=html.replace("</body>",`<script>${js.replace(/<\/script/gi,"<\\/script")}<\/script></body>`);
 return html;
}
function run(){
 save();$("logs").innerHTML="";log("info","Building project…");
 const html=buildHTML();const frame=$("preview");frame.srcdoc=html;
 frame.onload=()=>log("ok","Build successful — preview refreshed.");
 setTimeout(()=>log("info","Sandbox: browser-only HTML/CSS/JS execution."),120);
}
$("run").onclick=run;$("save").onclick=()=>{save();log("ok","Project files saved locally.")};
$("refresh").onclick=run;
$("clear").onclick=()=>$("logs").innerHTML="";
$("theme").onclick=()=>{document.body.classList.toggle("light");localStorage.setItem("studio-theme",document.body.classList.contains("light")?"light":"dark")};
if(localStorage.getItem("studio-theme")==="light")document.body.classList.add("light");
$("deviceMobile").onclick=()=>{$("preview").classList.add("mobile");$("deviceMobile").classList.add("active");$("deviceDesktop").classList.remove("active")};
$("deviceDesktop").onclick=()=>{$("preview").classList.remove("mobile");$("deviceDesktop").classList.add("active");$("deviceMobile").classList.remove("active")};
$("newFile").onclick=()=>$("modal").classList.remove("hidden");$("close").onclick=()=>$("modal").classList.add("hidden");
$("createFile").onclick=()=>{let n=$("fileName").value.trim();if(!n)return;if(files[n]){alert("File already exists.");return}files[n]="";current=n;save();renderFiles();renderTabs();openFile(n);$("modal").classList.add("hidden");$("fileName").value=""};
renderFiles();openFile(current);
