# Phase 7 — Code Studio

## Included
- Project file explorer
- HTML/CSS/JavaScript editor
- Multi-file local workspace
- Run button
- Sandboxed iframe live preview
- Desktop/mobile preview switch
- Console/status panel
- Local save with localStorage
- Create new file
- Dark/light mode

## Security model
HTML/CSS/JS preview uses an iframe with `sandbox="allow-scripts"` and is intentionally browser-only. It does not execute arbitrary server-side code.

For production persistence, replace localStorage with authenticated Supabase project files and storage/version tables.

For languages such as Python, Java, C++, PHP or Node.js, use an isolated execution service/container. Do not execute untrusted code directly inside the main application server.

## Next integration
- Monaco Editor
- Supabase project files
- Autosave/version history
- Team collaboration
- Error diagnostics
- Secure server-side language runners
