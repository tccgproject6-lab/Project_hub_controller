# Phase 6 — Live Meetings

## Included
- Meeting scheduling UI
- Join meeting room
- Browser camera and microphone access using WebRTC media APIs
- Mute/unmute microphone
- Camera on/off
- Screen sharing with getDisplayMedia
- Participant panel foundation
- In-meeting chat UI
- End meeting controls
- Responsive meeting room
- Supabase meeting schema and RLS
- Realtime publication for meeting state/chat

## Important
The browser media layer is functional for the local host preview and screen capture. Multi-user calling requires a signaling layer and STUN/TURN configuration; those are intentionally not faked in this phase.

For production, use WebRTC with a signaling channel (Supabase Realtime can carry signaling messages) and a TURN service for networks where direct peer connectivity fails.

Never expose service-role credentials in frontend code.
